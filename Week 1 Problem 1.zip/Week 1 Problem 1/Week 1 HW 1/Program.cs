﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_1_HW_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter the length of your rectangle: ");
            int length = int.Parse(Console.ReadLine());

            Console.WriteLine("Please enter the length of your rectangle: ");
            int width = int.Parse(Console.ReadLine());

            Console.WriteLine("The area of your rectangle is: {0}", Calculate(length, width));
            Console.ReadLine();
        }

        public static int Calculate(int l, int w)
        {
            return l * w;
        }
    }
}
