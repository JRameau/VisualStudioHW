﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_1_HW_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter a number: ");
            int n = int.Parse(Console.ReadLine());

            Table(n);
            Console.ReadKey();
        }

        public static void Table(int n)
        {
            for (int i = 1; i < n + 1; i++)
            {
                for (int j = 1; j < n + 1; j++)
                {
                    Console.Write("{0} ", i * j);
                }
                Console.WriteLine();
            }
        }
    }
}



       